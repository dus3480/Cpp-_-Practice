// Win32PrintTemplate.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
class CTest
{
public:
	CTest() {}
	~CTest() {}
private:
};

int _tmain(int argc,_TCHAR argv[])
{
	dyPrint("Hello World");
	return 0;
}
